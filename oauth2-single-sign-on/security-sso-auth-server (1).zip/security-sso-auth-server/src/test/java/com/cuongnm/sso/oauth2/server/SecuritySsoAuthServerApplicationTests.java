package com.cuongnm.sso.oauth2.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuritySsoAuthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
